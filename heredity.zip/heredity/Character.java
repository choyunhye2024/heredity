package com.heredity2;

public class Character extends GameObj {

	int hp;
	int attack;

}
