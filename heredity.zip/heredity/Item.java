package com.heredity2;

public class Item extends GameObj {

	int weight;
	int 수명;

}
