package com.heredity2;

public class Sword extends Item {

	int attack;

}
